package com.example.scanner

import android.app.Application

class App: Application()